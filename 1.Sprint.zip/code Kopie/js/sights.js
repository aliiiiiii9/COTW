let sights = {
    sights: [
        {
            "name": "Argus 8-16x50 Rifle Scope",
            "magnification": "8-16x",
            "Price": "36000",
            "image": "../"
        },
        {
            "name": "Ascent 1-4x24 Rifle Scope",
            "magnification": "1-4x",
            "Price": "Free"
        },
        {
            "name": "Galileo 4-8x32 Muzzleloader Scope",
            "magnification": "4-8x",
            "Price": "Free"
        },
        {
            "name": "GenZero 1-4x20 Night Vision Rifle Scope",
            "magnification": "1-4x",
            "Price": "Free"
        },
        {
            "name": "Helios 4-8x32 Rifle Scope",
            "magnification": "4-8x",
            "Price": "24000"
        },
        {
            "name": "Hyperion 4-8x42 Rifle Scope",
            "magnification": "4-8x",
            "Price": "12000"
        },
        {
            "name": "Goshawk Redeye 2-4x20 Handgun Scope",
            "magnification": "2-4x",
            "Price": "12000"
        },
        {
            "name": "Red Raptor Reflex Sight",
            "magnification": "1x",
            "Price": "6000"
        },
        {
            "name": "Falcon 3-9x44 Drilling Scope",
            "magnification": "3-9x",
            "Price": "Free"
        },
        {
            "name": "Meridian 1-4x20 Shotgun Scope",
            "magnification": "1-4x",
            "Price": "Free"
        },
        {
            "name": "Brightsight Rangefinder Bow Sight",
            "magnification": "1x",
            "Price": "Free"
        },
        {
            "name": "Brightsight Single-Pin Sight",
            "magnification": "1x",
            "Price": "3000"
        },
        {
            "name": "Hawken 1-5x30 Crossbow Scope",
            "magnification": "1-5x",
            "Price": "Free"
        },
        {
            "name": "Swift-Mark 3 Bow Sight",
            "magnification": "1x",
            "Price": "12000"
        },
        {
            "name": "Swift-Mark 5 Bow Sight",
            "magnification": "1x",
            "Price": "24000"
        }
    ]
}